"""Validate release integrity without making network requests."""
import hashlib,json,pathlib,csv
from build import ROOT
def rows(name): return [json.loads(s) for s in (ROOT/name).read_text(encoding='utf-8').splitlines() if s]
def main():
    manifest=json.loads((ROOT/'manifest.json').read_text(encoding='utf-8'))
    upstream=json.loads((ROOT/'upstream_manifest.json').read_text(encoding='utf-8'))
    for path,digest in upstream['files'].items(): assert hashlib.sha256((ROOT.parent/path).read_bytes()).hexdigest()==digest,path
    ev=rows('6-Evidence/evidence.jsonl'); ids={x['evidence_id'] for x in ev}; assert len(ids)==len(ev)
    for e in ev:
        if e['sha256']: assert hashlib.sha256((ROOT/e['local_path']).read_bytes()).hexdigest()==e['sha256']
    events=rows('1-Event/screened_events.jsonl'); assert len(events)==203
    tx=rows('2-Transaction/observations.jsonl'); assert len(tx)==803
    mids=rows('3-Message/messages.jsonl'); midset={m['message_id'] for m in mids}; assert len(midset)==len(mids)
    txids={t['transaction_id'] for t in tx}; eventids={e['event_id'] for e in events}
    for m in mids:
        assert m['transaction_id'] in txids and set(m['event_ids'])<=eventids
        assert set(m['evidence_ids'])<=ids
        assert m['target_label'] in ('unknown','not_applicable') and not m['benchmark_eligible']
    checks=rows('5-Verification/checks.jsonl'); assert len(checks)==10*len(mids)
    for c in checks: assert c['message_id'] in midset and c['result']=='unknown'
    life=rows('4-Lifecycle/transitions.jsonl'); assert len(life)==7*len(mids)
    for x in life: assert x['message_id'] in midset and set(x['evidence_ids'])<=ids
    assert rows('benchmark/strict.jsonl')==[]
    for name in ('1-Event/screened_events','2-Transaction/observations','3-Message/messages','4-Lifecycle/transitions','5-Verification/checks','6-Evidence/evidence'):
        with (ROOT/(name+'.csv')).open(encoding='utf-8',newline='') as f: assert len(list(csv.DictReader(f)))==len(rows(name+'.jsonl'))
    assert len(mids)==manifest['message_candidates']
    print('PASS: upstream hashes, evidence hashes, identities, foreign keys, CSV/JSONL parity and conservative label gates')
if __name__=='__main__': main()
