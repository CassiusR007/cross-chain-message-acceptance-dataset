import concurrent.futures,datetime,hashlib,json,urllib.request
from collect import ROOT
def fetch(path):
    wrapper=json.loads(path.read_text(encoding='utf-8')); data=wrapper['data']
    if data.get('method') not in ('process','withdrawERC20For'): return
    out=path.with_name(path.stem+'-logs.json')
    if out.exists(): return
    url=wrapper['url']+'/logs'
    try:
        with urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'MAAD-research-dataset/0.1'}),timeout=25) as r: raw=r.read()
        d=json.loads(raw)
        out.write_text(json.dumps({'url':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'response_sha256':hashlib.sha256(raw).hexdigest(),'response_text':raw.decode(),'data':d},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        print(path.stem,'logs',len(d.get('items',[])),'partial',bool(d.get('next_page_params')))
    except Exception as e: print(path.stem,type(e).__name__)
if __name__=='__main__':
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: list(pool.map(fetch,[p for p in (ROOT/'6-Evidence/raw').glob('TXN-*.json') if '-logs' not in p.stem]))
