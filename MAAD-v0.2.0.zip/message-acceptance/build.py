"""Deterministic, offline exports from frozen upstream files and cached evidence."""
import csv, hashlib, json, pathlib, collections
ROOT=pathlib.Path(__file__).resolve().parent
PREDICATES={
 'SRC_AUTH':'消息由授权源域和源合约发出', 'SRC_VALUE':'源端锁定或销毁与消息资产承诺一致',
 'PROOF_BINDING':'证明绑定同一消息、路径和可信承诺', 'STATE_ROOT':'接受根属于可信已确认状态',
 'QUORUM':'签名者集合、阈值和授权语义有效', 'FINALITY':'源状态满足协议最终性条件',
 'STATE_ORDER':'消息按协议要求完成先决状态转换', 'REPLAY':'同一消息未被重复消费',
 'EXEC_AUTH':'执行目标、资产和接收人符合消息授权', 'RECOVERY_PATH':'恢复或特权路径保持等价验证约束'}

def read_csv(path):
    with path.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f))
def write_json(path,data):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def export(stem,rows,fields=None):
    path=ROOT/stem; path.parent.mkdir(parents=True,exist_ok=True)
    path.with_suffix('.jsonl').write_text(''.join(json.dumps(r,ensure_ascii=False)+'\n' for r in rows),encoding='utf-8')
    fields=list(rows[0]) if rows else fields
    with path.with_suffix('.csv').open('w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
        for row in rows: w.writerow({k:json.dumps(v,ensure_ascii=False) if isinstance(v,(dict,list,bool)) else v for k,v in row.items()})

def strict_label(acceptance,results,verified=False,coverage_complete=False):
    if acceptance=='rejected': return 'not_applicable'
    if acceptance!='accepted' or not verified or not results: return 'unknown'
    if 'fail' in results: return 'abnormal_acceptance'
    if coverage_complete and all(x in ('pass','not_applicable') for x in results) and 'pass' in results: return 'valid_acceptance'
    return 'unknown'

def decode_nomad(value):
    b=bytes.fromhex(value.removeprefix('0x'))
    if len(b)<76: raise ValueError('Truncated Nomad message')
    return {'origin_domain':int.from_bytes(b[:4],'big'),'sender':'0x'+b[4:36].hex(),
            'nonce':int.from_bytes(b[36:40],'big'),'destination_domain':int.from_bytes(b[40:44],'big'),
            'recipient':'0x'+b[44:76].hex(),'body':'0x'+b[76:].hex()}

def params(decoded): return {p['name']:p.get('value') for p in (decoded or {}).get('parameters',[])}
def main():
    events=read_csv(ROOT.parent/'1-Event/events.csv'); txs=read_csv(ROOT.parent/'2-Transaction/transactions.csv')
    annotations=json.loads((ROOT/'annotations/event_scope.json').read_text(encoding='utf-8'))
    assert set(annotations)=={e['event_id'] for e in events}
    cards={p.stem:json.loads(p.read_text(encoding='utf-8')) for p in (ROOT.parent/'1-Event/event_description').glob('*.json')}
    evidence=[]; reports={}; snapshots={}; observations=[]; messages=[]; lifecycle=[]; verification=[]; issues=[]
    for eid,card in sorted(cards.items()):
        reports[eid]=[]
        for i,ref in enumerate(card.get('references',[])):
            rid=f'REF-{eid}-{i+1:03d}'; reports[eid].append(rid)
            evidence.append({'evidence_id':rid,'kind':'inherited_report_reference','url':ref.get('url'),
                'title':ref.get('title'),'event_id':eid,'transaction_id':None,'local_path':f'../1-Event/event_description/{eid}.json',
                'sha256':None,'retrieved_at':None,'scope':'event','limitations':'Reference inherited from upstream; not a per-message semantic proof.'})
    for p in sorted((ROOT/'6-Evidence/raw').glob('*.json')):
        w=json.loads(p.read_text(encoding='utf-8')); d=w['data']; islog=p.stem.endswith('-logs'); tid=p.stem.replace('-logs','')
        assert hashlib.sha256(w['response_text'].encode()).hexdigest()==w['response_sha256']
        assert json.loads(w['response_text'])==d
        evidence_id='OBS-'+p.stem; snapshots[p.stem]=d
        evidence.append({'evidence_id':evidence_id,'kind':'explorer_logs' if islog else 'explorer_transaction','url':w['url'],
            'title':None,'event_id':None,'transaction_id':tid,'local_path':str(p.relative_to(ROOT)).replace('\\','/'),
            'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'retrieved_at':w['retrieved_at'],'scope':'transaction',
            'limitations':'Explorer observation, not independently replayed. Current address tags/implementation metadata are not historical features.'})
    screened=[]
    for event in events:
        eid=event['event_id']; a=annotations[eid]
        screened.append({'event_id':eid,'event_name':event['event_name'],'event_date':event['event_date'] or None,
            'record_type':event['record_type'],**a,'evidence_ids':reports.get(eid,[]),'review_status':'provisional_screening'})
    for tx in txs:
        tid=tx['transaction_id']; d=snapshots.get(tid); event_ids=json.loads(tx['event_ids'])
        observations.append({'transaction_id':tid,'event_ids':event_ids,'chain':tx['chain'] or None,'tx_hash':tx['tx_hash'] or None,
            'upstream_label_status':tx['label_status'],'block_number':d.get('block_number') if d else None,
            'timestamp':d.get('timestamp') if d else None,'transaction_status':d.get('status') if d else None,
            'evidence_level':'onchain_observed' if d else 'inherited_candidate','evidence_ids':['OBS-'+tid] if d else [],
            'message_extraction':'not_attempted' if not d else 'unsupported_call_or_internal_trace_required'})
        if not d: continue
        assert d['hash'].lower()==tx['tx_hash'].lower()
        address=(d.get('to') or {}).get('hash','').lower(); method=d.get('method'); decoded=d.get('decoded_input') or {}
        protocol=None; fields={}; protocol_id=None
        if address=='0x5d94309e5a0090b165fa4181519701637b6daeba' and method=='process' and decoded.get('method_id')=='928bc4b2':
            protocol='Nomad'; values=decoded.get('parameters',[])
            if len(values)!=1 or values[0]['type']!='bytes': continue
            payload=values[0]['value']; fields=decode_nomad(payload)
        elif address=='0x1a2a1c938ce3ec39b6d47113c7955baa9dd454f2' and method=='withdrawERC20For':
            protocol='Ronin'; fields=params(decoded); protocol_id=fields.get('_withdrawalId'); payload=d.get('raw_input')
        else: continue
        mid='MSG-'+tid+'-call0'; eids=['OBS-'+tid]; acceptance='unknown'; execution='unknown'; log_index=None
        logs=snapshots.get(tid+'-logs',{}); matching=[]
        for log in logs.get('items',[]):
            if log.get('transaction_hash','').lower()!=tx['tx_hash'].lower(): continue
            if (log.get('address') or {}).get('hash','').lower()!=address: continue
            name=(log.get('decoded') or {}).get('method_call','')
            if protocol=='Nomad' and name.startswith('Process('): matching.append(log)
        if d.get('status')=='error': acceptance='rejected'; execution='reverted'
        elif protocol=='Nomad' and len(matching)==1 and not logs.get('next_page_params') and d.get('status')=='ok':
            log=matching[0]; values=params(log['decoded']); protocol_id=values.get('messageHash')
            acceptance='accepted'; execution='succeeded' if str(values.get('success')).lower()=='true' else 'failed'
            log_index=log.get('index'); eids.append('OBS-'+tid+'-logs')
        # Ronin call success alone is insufficient for a message-acceptance label in this release.
        message={'message_id':mid,'identity_kind':'dataset_destination_call_id','protocol_message_id':protocol_id,
            'protocol':protocol,'event_ids':event_ids,'transaction_id':tid,'destination_chain':'Ethereum',
            'destination_contract':address,'call_path':'top_level','log_index':log_index,'message_bytes':payload,
            'decoded_fields':fields,'acceptance_outcome':acceptance,'execution_outcome':execution,
            'target_label':strict_label(acceptance,[]),'evidence_level':'onchain_observed','evidence_ids':eids,
            'acceptance_basis':'unique_same_contract_Process_log; calldata_hash_binding_not_independently_checked' if acceptance=='accepted' else 'insufficient_or_reverted',
            'benchmark_eligible':False,'label_reason':'Source origin, historical verification state and per-message validity have not been independently established.'}
        messages.append(message); observations[-1]['message_extraction']='top_level_call_decoded'
        for stage in ['source_emission','commitment','attestation_or_proof','destination_submission','destination_acceptance','execution','recovery']:
            observed=stage=='destination_submission' or (stage in ('destination_acceptance','execution') and acceptance!='unknown')
            outcome='observed' if stage=='destination_submission' else acceptance if stage=='destination_acceptance' else execution if stage=='execution' else 'unknown'
            lifecycle.append({'lifecycle_id':mid+'-'+stage,'message_id':mid,'stage':stage,'observation_status':'observed' if observed else 'unknown',
                'outcome':outcome if observed else 'unknown','timestamp':d.get('timestamp') if observed else None,
                'block_number':d.get('block_number') if observed else None,'transaction_id':tid if observed else None,
                'evidence_ids':eids if observed else [],'available_at':'after_destination_inclusion' if observed else 'unknown'})
        for predicate,expectation in PREDICATES.items():
            verification.append({'message_id':mid,'predicate_id':predicate,'applicability':'unknown','expected':expectation,
                'observed':None,'result':'unknown','evidence_ids':[],'verification_method':None,
                'missing_reason':'Requires historical source/destination state and protocol-specific verification; incident-level root cause is not sufficient.'})
    collection=json.loads((ROOT/'6-Evidence/collection_log.json').read_text(encoding='utf-8'))
    for tid,status in collection:
        if status not in ('ok','cached'): issues.append({'transaction_id':tid,'issue':'explorer_fetch_failed','detail':status,'interpretation':'Not proof of nonexistent transaction; retry or use another provider.'})
    export('1-Event/screened_events',screened); export('2-Transaction/observations',observations)
    export('3-Message/messages',messages,['message_id','target_label']); export('4-Lifecycle/transitions',lifecycle,['lifecycle_id','message_id'])
    export('5-Verification/checks',verification,['message_id','predicate_id']); export('6-Evidence/evidence',evidence)
    write_json(ROOT/'5-Verification/predicates.json',PREDICATES); write_json(ROOT/'quality_issues.json',issues)
    export('benchmark/strict',[],['message_id','target_label','split'])
    write_json(ROOT/'benchmark/split_policy.json',{'status':'not_created_no_verified_controls','unit':'connected_event_campaign_components',
        'rule':'Group all shared-event, shared-message and known shared-campaign records before assigning splits. Never split rows randomly.',
        'forbidden_features':['event_name','event_id','report_title','description','loss_amount','post_incident_address_tags','target_label','future_recovery'],'sampling':'Convenience sample of upstream Ethereum entries; not representative of all messages.'})
    files=[ROOT.parent/'README.upstream.md',ROOT.parent/'LICENSE']+list((ROOT.parent/'1-Event').rglob('*'))+list((ROOT.parent/'2-Transaction').rglob('*'))
    write_json(ROOT/'upstream_manifest.json',{'repository':'https://github.com/justinzjj/Cross-chain-anomaly-event-dataset','commit':'bdb0893c51cca7ce2dee52f8228b90bab4d0f290',
        'files':{str(p.relative_to(ROOT.parent)).replace('\\','/'):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files) if p.is_file()}})
    stats={'version':'0.1.0','release_date':'2026-09-22','upstream_events':len(events),'upstream_transactions':len(txs),
        'screened_events':len(screened),'scope_counts':dict(collections.Counter(e['scope'] for e in screened)),
        'observed_transactions':sum(bool(snapshots.get(t['transaction_id'])) for t in txs),'message_candidates':len(messages),
        'accepted_observations':sum(m['acceptance_outcome']=='accepted' for m in messages),'semantically_verified_messages':0,
        'strict_benchmark_records':0,'lifecycle_rows':len(lifecycle),'predicate_rows':len(verification),'evidence_records':len(evidence),'fetch_issues':len(issues)}
    write_json(ROOT/'manifest.json',stats); print(json.dumps(stats,ensure_ascii=False,indent=2))
if __name__=='__main__': main()
