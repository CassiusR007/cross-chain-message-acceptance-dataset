# v0.1.0 release checks

2026-09-22: six unit tests passed; offline integrity validation passed (upstream/evidence SHA-256, unique IDs, foreign keys, CSV/JSONL row parity, and strict label gates).

Independent code review found no critical defect in the frozen labels and identified two hardening points. The normal-label helper now requires explicit coverage completeness. Acceptance-log uniqueness now requires a complete first page. Calldata-to-log Keccak binding remains unverified and is explicitly recorded in acceptance_basis and DATA_CARD.md; all semantic target labels remain unknown. Review is code/data consistency review, not independent forensic confirmation of attacks.

All 24 collected message log responses had no next-page cursor. Two transaction lookups returned 404; these are retrieval issues, not evidence of nonexistent transactions. Current strict benchmark has no records and no train/test split.
