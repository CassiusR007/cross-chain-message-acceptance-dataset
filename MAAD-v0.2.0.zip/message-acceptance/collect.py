"""Collect public explorer observations; cached responses are immutable inputs to build.py."""
import concurrent.futures, csv, datetime, hashlib, json, pathlib, urllib.request
ROOT=pathlib.Path(__file__).resolve().parent

def fetch(row):
    txid=row['transaction_id']; out=ROOT/'6-Evidence'/'raw'/f'{txid}.json'
    if out.exists(): return txid,'cached'
    url='https://eth.blockscout.com/api/v2/transactions/'+row['tx_hash']
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'MAAD-research-dataset/0.1'})
        with urllib.request.urlopen(req,timeout=25) as r: body=r.read()
        data=json.loads(body)
        if data.get('hash','').lower()!=row['tx_hash'].lower(): raise ValueError('hash mismatch')
        wrapper={'url':url,'retrieved_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
                 'response_sha256':hashlib.sha256(body).hexdigest(),'response_text':body.decode(),'data':data}
        out.parent.mkdir(parents=True,exist_ok=True)
        out.write_text(json.dumps(wrapper,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
        return txid,'ok'
    except Exception as e: return txid,type(e).__name__+': '+str(e)

def main():
    with (ROOT.parent/'2-Transaction/transactions.csv').open(encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
    selected=[]
    for event,limit in [('EVT-000042',40),('EVT-000029',10),('EVT-000013',10),('EVT-000022',10),('EVT-000024',10)]:
        selected.extend([r for r in rows if event in json.loads(r['event_ids']) and r['chain']=='Ethereum' and r['tx_hash']][:limit])
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool: results=list(pool.map(fetch,selected))
    (ROOT/'6-Evidence').mkdir(exist_ok=True)
    (ROOT/'6-Evidence/collection_log.json').write_text(json.dumps(results,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(results))
if __name__=='__main__': main()
