# Cross-chain Message Acceptance Dataset (MAAD)

基于**跨链消息生命周期与验证语义**的异常消息接受检测候选数据集。

> v0.1.0 是带来源和链上观测的研究候选集，**不是已完成语义验证的监督学习基准**。当前严格基准为 0 条；未知标签不能当作正常样本。

基于 [justinzjj/Cross-chain-anomaly-event-dataset](https://github.com/justinzjj/Cross-chain-anomaly-event-dataset/tree/bdb0893c51cca7ce2dee52f8228b90bab4d0f290) 构建，保留原始事件、交易、事件卡、编号及 MIT 许可，新增范围筛选、消息恢复、生命周期和验证谓词层。原说明见 [README.upstream.md](README.upstream.md)。本仓库为独立衍生项目，不代表上游作者背书。

## 本版包含

- 203 条上游事件记录、803 条交易记录；其中事件记录含 33 条待拆分组，不等于 203 起独立攻击。
- 全量暂定事件筛选：87 条相关、50 条边界、21 条排除、45 条待定，保留理由和来源。
- 27 条公开事件研究线索，含安全公司/项目方来源、生命周期阶段和检测推论。
- 61 笔 Ethereum 历史交易观测；24 条顶层调用候选（22 条 Nomad、2 条 Ronin）。
- 22 条 Nomad 接受观察、168 条生命周期记录、240 条待核实的逐消息谓词记录。
- 464 条来源/观测索引；85 份公开交易或日志响应快照。

严格语义真值仍为 0：未逐消息核实源链事实、历史验证状态、适用协议约束，也没有已验证正常对照。范围相关、交易成功、Process 日志、事件级攻击结论分别表达不同事实。

## 使用入口

- [数据卡与标注规则](message-acceptance/DATA_CARD.md)：单位、标签、局限、泄漏控制、重建方式。
- [事件筛选 CSV](message-acceptance/1-Event/screened_events.csv) / [消息 CSV](message-acceptance/3-Message/messages.csv)。
- [生命周期 CSV](message-acceptance/4-Lifecycle/transitions.csv) / [验证谓词 CSV](message-acceptance/5-Verification/checks.csv)。
- [来源索引 CSV](message-acceptance/6-Evidence/evidence.csv) / [公开报告研究索引](message-acceptance/research_sources.json)。
- [统计清单](message-acceptance/manifest.json) / [取证问题清单](message-acceptance/quality_issues.json)。

每张导出表均有 JSONL；复杂 CSV 单元格是 JSON。根目录 `1-Event/`、`2-Transaction/` 是上游原始数据；新增表位于 `message-acceptance/`。

```sh
python -m unittest discover -s message-acceptance -p 'test_*.py'
python message-acceptance/build.py
python message-acceptance/validate.py
```

Python 3.10+，离线重建无需第三方依赖。采集脚本用于可选更新，已有缓存不覆盖。新增协议应加入历史实现/配置、完整日志或调用轨迹、源目标配对和谓词取证，不应把每笔交易自动视为一条消息。

## 贡献与许可

欢迎提交带来源的修订；请附事件/交易/消息标识、链、证据位置、观测时点、协议版本与标签理由。报告级怀疑和链上实测分开记录。正负样本升格必须经过独立复核；按事件/活动分组划分数据，禁止逐行随机切分造成泄漏。

遵循 [MIT License](LICENSE)，保留上游 Justin Zhou 的版权声明。新增代码和标注也采用 MIT。第三方报告与区块浏览器内容的权利仍归原作者/提供方。
