# v0.1 implementation ledger

User approved a public derivative dataset on 2026-09-22.

1. Preserve the upstream event/transaction files and license, pin the source revision.
2. Separate inherited event screening, observed destination calls, and verified semantic labels.
3. Fetch public Ethereum explorer evidence for representative Nomad and Ronin calls.
4. Export message/lifecycle/predicate/evidence tables; prohibit unknown predicates becoming negative samples.
5. Validate identities, evidence hashes, referential integrity and label gates; publish to a new user-owned repository.

Historical source-chain state and complete valid controls are not assumed available. Until those are checked, the strict supervised benchmark stays empty; candidate observations remain useful for annotation and detector development.
