import unittest
from build import decode_nomad, strict_label

class SemanticsTests(unittest.TestCase):
    def test_unknown_is_not_normal(self):
        self.assertEqual(strict_label('accepted', ['unknown']), 'unknown')
    def test_revert_is_not_abnormal_acceptance(self):
        self.assertEqual(strict_label('rejected', ['fail']), 'not_applicable')
    def test_fail_requires_semantic_verification(self):
        self.assertEqual(strict_label('accepted', ['fail']), 'unknown')
        self.assertEqual(strict_label('accepted', ['fail'], True), 'abnormal_acceptance')
    def test_no_vacuous_validity(self):
        self.assertEqual(strict_label('accepted', [], True), 'unknown')
    def test_incomplete_coverage_is_not_normal(self):
        self.assertEqual(strict_label('accepted', ['pass'], True), 'unknown')
        self.assertEqual(strict_label('accepted', ['pass'], True, True), 'valid_acceptance')
    def test_decode_packed_message(self):
        raw=(1).to_bytes(4,'big')+bytes(32)+(7).to_bytes(4,'big')+(2).to_bytes(4,'big')+bytes(32)+b'abc'
        self.assertEqual(decode_nomad('0x'+raw.hex())['nonce'],7)
        with self.assertRaises(ValueError): decode_nomad('0x00')

if __name__=='__main__': unittest.main()
