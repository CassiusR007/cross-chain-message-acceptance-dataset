# 数据卡：跨链消息生命周期与验证语义异常接受候选集

## 目的与单位

用于研究“目标端是否接受了不满足协议验证语义的跨链消息”。事件是检索单位，交易是取证入口，消息/目标端调用才是标签单位。一个交易可包含多条内部消息；本版仅解码指定协议的顶层调用，不将未解码交易强制转换成消息。`MSG-TXN-…-call0` 是本数据集的局部标识，不是协议原生消息 ID。协议 ID 另存 `protocol_message_id`；Ronin 是 withdrawal ID，Nomad 是日志中的 messageHash，二者不可直接比较。

## 覆盖和抽样

来源为上游固定版本的 203 个事件记录、803 个交易记录。203 条包括 33 条待拆分事件组，不能全部称作独立攻击。上游 CSV 和 161 张事件卡保留原样，位于仓库根目录 `1-Event/`、`2-Transaction/`。`README.upstream.md` 保留原始说明。来源固定于 bdb0893c51cca7ce2dee52f8228b90bab4d0f290，文件摘要见 upstream_manifest.json。

本版对全部事件做暂定范围筛选；该筛选由模型辅助整理、尚未双人复核，继承的根因说明不构成独立事实核验。选取 Nomad、Ronin、Poly Network、Qubit、Meter 中的 Ethereum 候选交易取证；每事件按上游排序取有限条目，是便利抽样，不是随机样本，也不代表完整攻击链。只处理 Nomad 指定 Replica 的 process(bytes) 与 Ronin 指定网关的 withdrawERC20For 顶层调用。原始证据中其它协议的调用保留用于后续扩展。

## 标签与证据

- scope：in_scope、boundary、out_of_scope、unresolved；表示研究相关性，不是交易恶意性。
- case_nature：攻击、白帽救援、失败尝试、运行故障、漏洞披露或未知。不能把披露当作真实资金攻击。
- acceptance_outcome：accepted、rejected、unknown；execution_outcome 独立，接收后下游执行仍可能失败。
- target_label：abnormal_acceptance、valid_acceptance、unknown、not_applicable。
- evidence_level：inherited_candidate、report_supported、onchain_observed、semantically_verified。本版消息均为 onchain_observed；链上交易成功不等于验证语义正确。
- predicate.result：pass、fail、unknown、not_applicable。当前逐消息验证全部 unknown；事件的可疑谓词只指导人工检查。

Nomad 的 accepted 表示成功交易中同一 Replica 发出唯一 Process 日志，按顶层调用关联；messageHash 来自日志，本版未独立计算 calldata 的 Keccak，也未重放历史实现。该观察不能证明源端消息存在、根合法、签名未泄露或经济语义有效。Ronin 仅恢复提款参数，acceptance 保留 unknown。

**严格基准当前 0 条。没有经过验证的正常对照；不得将 unknown、associated、excluded 或检索失败作为正常负样本。不得据此报告监督学习准确率。** 用户可用候选表开展数据清洗、消息恢复和标注研究；若作弱监督，必须自行声明事件级推断而非本数据集提供的消息真值。

## 生命周期和谓词

生命周期按 source_emission → commitment → attestation_or_proof → destination_submission → destination_acceptance → execution → recovery 表达观测，unknown 表示尚未取证，不代表阶段未发生。它是通用分析框架，不要求每个协议都具有完全相同的步骤。

验证字典覆盖 SRC_AUTH、SRC_VALUE、PROOF_BINDING、STATE_ROOT、QUORUM、FINALITY、STATE_ORDER、REPLAY、EXEC_AUTH、RECOVERY_PATH。每次检查独立记录 applicability、expected、observed、result、evidence_ids、missing_reason。

升格为异常真值至少需要：可识别消息、接收证据、适用的协议/实现版本，以及一个可独立复核的语义违反。正常真值还需覆盖全部适用谓词。有效阈值签名可能来自被盗密钥，单凭签名通过不能证明授权业务事实。历史状态必须采用交易前状态；同区块前序交易会改变状态，不能不加说明地用整个前一区块代替。

## 泄漏、分组与缺失

离线检测须先界定观察时点。本版 available_at=after_destination_inclusion 的字段只能用于落块后检测，不可冒充接收前防护特征。报告标题、事后损失、攻击者标签、事件 ID/名称、恢复情况与解释文本不得作为在线输入。Explorer 当前代理实现、资产价格和声誉标签仅出现在原始证据，不能当作历史事实。

未来划分必须以事件/活动连通分量为组；共享事件、同一消息的重复尝试、同一攻击活动不能跨训练与测试集。当前 campaign_group 默认事件 ID，跨事件活动归并仍待人工检查，尚不产生 train/test。空标量对应未知，JSON null、CSV 空值；数组和对象在 CSV 中为 JSON 文本。哈希大小写保留；比对应当按链和该链规范处理。

## 可复现与限制

Python 3.10+，构建和测试只使用标准库。在仓库根运行：

```sh
python -m unittest discover -s message-acceptance -p 'test_*.py'
python message-acceptance/build.py
python message-acceptance/validate.py
```

可选联网采集 `python message-acceptance/collect.py`，再运行 collect_logs.py。已有缓存不覆盖；网络失败保留在 collection_log.json。日志接口本版只保存第一页，next_page_params 非空时证据不完整，后续完整性检查不得据此断言没有其他日志。归档包含响应原文、获取时间、SHA-256 与解析结果；哈希证明保存后未改动，不证明提供方正确。查询失败不能证明链上无此交易。

外部报告版权归各作者，保留链接和简要自行整理摘要，不重新授权第三方全文。模板遵循原 MIT 许可，新编写代码与标注同样以 MIT 发布。公开链上地址仅作技术研究，不据此识别自然人或归责。
