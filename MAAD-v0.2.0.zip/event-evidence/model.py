"""Offline evidence gates. A report-supported event is not message-level truth."""
import csv
import json
import re
from datetime import date

TABLE_KEYS={'events':'event_id','sources':'source_id','claims':'claim_id','upstream_map':'upstream_event_id','case_map':'legacy_case_id','transaction_links':'link_id','search_log':'search_id'}
ENUMS={
 'record_type':{'event','unresolved_group'},'scope':{'in_scope','boundary','out_of_scope','unresolved'},
 'case_nature':{'malicious_attack','whitehat','failed_attempt','vulnerability_disclosure','operational_failure','unknown'},
 'review_status':{'report_supported','inherited_candidate','unresolved'},
 'semantic_categories':{'VALUE_CONSERVATION','SOURCE_SEMANTICS','EMITTER_AUTH','EXEC_AUTH','TRUST_CONFIG','PROOF_VALIDITY','PROOF_BINDING','SIGNER_TRUST','OBSERVATION_TRUST','ASSET_BINDING','REPLAY','DOMAIN_BINDING','FINALITY'},
 'lifecycle_stages':{'source_observation','attestation','verification','acceptance','execution'},
}
READ={'full_text_read','partial_text_read'}

def is_core_event(e):
    return (e['record_type']=='event' and e['scope']=='in_scope' and e['case_nature'] in {'malicious_attack','whitehat'} and e['review_status']=='report_supported' and not any(c.get('blocks_core') for c in e.get('conflicts',[])))

def require_acceptance_evidence(e,claims,sources):
    if not any(c['event_id']==e['event_id'] and c['claim_type']=='acceptance_mechanism' and c['stance']=='supports' and c.get('locator') and sources.get(c['source_id'],{}).get('access_status') in READ for c in claims):
        raise ValueError('No directly read mechanism evidence: '+e['event_id'])

def source_roots(sources):
    return {s['evidence_origin_id'] for s in sources if s.get('evidence_origin_id') and s['independence_status'] in {'established','derived'}}

def need(ok,message):
    if not ok: raise ValueError(message)

def validate_tables(tables,root):
    ids={}
    for t,key in TABLE_KEYS.items():
        rows=tables[t]; values=[r[key] for r in rows]
        need(len(values)==len(set(values)), 'Duplicate ID: '+t)
        ids[t]=set(values)
        if rows: need(all(set(r)==set(rows[0]) for r in rows),'Inconsistent columns: '+t)
    src={r['source_id']:r for r in tables['sources']}
    ev={r['event_id']:r for r in tables['events']}
    need(len({s['url'] for s in src.values()})==len(src),'Duplicate source URL')
    for s in src.values():
        need(s['access_status'] in READ|{'search_snippet_only','unavailable'},'Invalid access status')
        need(s['independence_status'] in {'established','derived','unknown'},'Invalid independence')
        need(s['url'].startswith('https://'),'Source URL must be HTTPS')
        need(bool(s['locator']) and bool(s['access_notes']),'Source lacks locator/access notes')
        need(s['evidence_origin_id'] is None or s['evidence_origin_id'] in ids['sources'],'Evidence origin FK')
        if s['published_at'] is not None: date.fromisoformat(s['published_at'])
        if s['independence_status']=='unknown': need(s['evidence_origin_id'] is None,'Unknown independence cannot count root')
    for e in ev.values():
        need(re.fullmatch(r'MAAD-E\d{6}',e['event_id']) is not None,'Invalid event ID')
        for k,valid in ENUMS.items():
            need(set(e[k])<=valid if isinstance(e[k],list) else e[k] in valid,'Invalid event '+k)
        need(set(e['source_ids'])<=ids['sources'],'Event source FK')
        need(bool(e['scope_reason']),'Missing scope rationale')
        if e['event_date']:
            need(date.fromisoformat(e['event_date'])<=date(2026,9,22),'Event after cutoff')
        if e['review_status']=='report_supported':
            need(any(c['event_id']==e['event_id'] and c['stance']=='supports' and src[c['source_id']]['access_status'] in READ for c in tables['claims'] if c['source_id'] in src),'Report-supported event without read support')
        if e['scope']=='in_scope' and e['review_status']=='report_supported': require_acceptance_evidence(e,tables['claims'],src)
    for c in tables['claims']:
        need(c['event_id'] in ids['events'] and c['source_id'] in ids['sources'],'Claim foreign key')
        need(c['source_id'] in ev[c['event_id']]['source_ids'],'Claim source missing from event')
        need(c['claim_type'] in {'occurrence','acceptance_mechanism','root_cause','date','transaction','loss','recovery'},'Invalid claim type')
        need(c['stance'] in {'supports','contradicts','context'},'Invalid stance')
        need(bool(c['locator']) and bool(c['statement_zh']),'Empty claim')
    for table in ('upstream_map','case_map'):
        for r in tables[table]:
            need(set(r['event_ids'])<=ids['events'],'Mapping foreign key')
            states={'matched','split','unresolved_group','excluded'} if table=='upstream_map' else {'report_supported','inherited_candidate','unresolved'}
            need(r['disposition'] in states,'Invalid mapping disposition')
            need(bool(r['review_basis'] if table=='upstream_map' else r['reason']),'Missing mapping rationale')
            if table=='case_map':need(set(r['source_ids'])<=ids['sources'],'Case source FK')
    with (root/'1-Event/events.csv').open(encoding='utf-8-sig') as f:
        upstream=list(csv.DictReader(f))
    cases=json.loads((root/'message-acceptance/research_sources.json').read_text(encoding='utf-8'))['cases']
    need(ids['upstream_map']=={r['event_id'] for r in upstream},'Upstream coverage mismatch')
    need(ids['case_map']=={r['id'] for r in cases},'Legacy case coverage mismatch')
    tx_keys=[]
    for t in tables['transaction_links']:
        need(t['event_id'] in ids['events'] and set(t['source_ids'])<=ids['sources'],'Transaction FK')
        need(t['verification_status']=='report_link_only','No onchain verification performed in this layer')
        need(re.fullmatch(r'(0x)?[0-9a-fA-F]{64}',t['tx_hash']) is not None,'Incomplete transaction hash')
        need(t['role'] in {'preparation','submission','acceptance','execution','transfer','unknown'},'Invalid tx role')
        tx_keys.append((t['event_id'],t['chain'],t['tx_hash'].lower()))
    need(len(tx_keys)==len(set(tx_keys)),'Duplicate transaction relation')
    return True
