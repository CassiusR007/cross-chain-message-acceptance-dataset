"""Validate evidence, deterministic exports, CSV round trips and frozen inputs."""
import csv
import hashlib
import json
from pathlib import Path
from build import ROOT,load_tables,outputs,decode_cell,readme_block,replace_readme_block
from model import TABLE_KEYS,validate_tables

def main():
    tables=load_tables(ROOT/'curation');validate_tables(tables,ROOT.parent)
    expected=outputs(tables)
    for rel,content in expected.items():
        if (ROOT/rel).read_bytes()!=content:raise ValueError('Stale export: '+rel)
    for name,rows in tables.items():
        prototypes={r[TABLE_KEYS[name]]:r for r in rows}
        with (ROOT/'data'/f'{name}.csv').open(encoding='utf-8',newline='') as f:
            csvrows=list(csv.DictReader(f))
        if len(csvrows)!=len(rows):raise ValueError('CSV row count: '+name)
        for r in csvrows:
            original=prototypes[r[TABLE_KEYS[name]]]
            if {k:decode_cell(v,original[k]) for k,v in r.items()}!=original:raise ValueError('CSV roundtrip: '+name)
    frozen=json.loads((ROOT.parent/'release/inputs.json').read_text(encoding='utf-8'))
    for entry in frozen['files']:
        p=ROOT.parent/entry['path']
        if hashlib.sha256(p.read_bytes()).hexdigest()!=entry['sha256']:raise ValueError('Frozen input changed: '+entry['path'])
    stats=json.loads((ROOT/'statistics.json').read_text(encoding='utf-8'))
    for file,en in [('README.md',False),('README.en.md',True)]:
        text=(ROOT.parent/file).read_text(encoding='utf-8')
        if text!=replace_readme_block(text,readme_block(stats,en)):raise ValueError('Stale README statistics: '+file)
    print(json.dumps({'status':'PASS','tables':len(tables),'core_events':stats['core_events'],'frozen_files':len(frozen['files']),'new_semantically_verified_messages':0}))
if __name__=='__main__':main()
