"""Deterministic exports; edit curation/*.jsonl, then rebuild."""
import csv
import io
import json
from collections import Counter
from pathlib import Path
from model import TABLE_KEYS,is_core_event,validate_tables,source_roots
ROOT=Path(__file__).resolve().parent

def load_tables(folder):
    return {t:[json.loads(line) for line in (folder/(t+'.jsonl')).read_text(encoding='utf-8').splitlines() if line.strip()] for t in TABLE_KEYS}

def encode_cell(v):
    if v is None:return ''
    if isinstance(v,(list,dict,bool,int,float)):return json.dumps(v,ensure_ascii=False,separators=(',',':'))
    return v

def decode_cell(v,prototype):
    if prototype is None:return None if v=='' else v
    if isinstance(prototype,(list,dict,bool,int,float)):return json.loads(v)
    return v

def json_bytes(obj): return (json.dumps(obj,ensure_ascii=False,indent=2)+'\n').encode('utf-8')

def outputs(tables):
    validate_tables(tables,ROOT.parent)
    files={}
    for name,rows in tables.items():
        ordered=sorted(rows,key=lambda r:r[TABLE_KEYS[name]])
        files['data/'+name+'.jsonl']=(''.join(json.dumps(r,ensure_ascii=False,separators=(',',':'))+'\n' for r in ordered)).encode('utf-8')
        out=io.StringIO(newline='');w=csv.DictWriter(out,fieldnames=list(ordered[0]),lineterminator='\n');w.writeheader()
        w.writerows({k:encode_cell(v) for k,v in r.items()} for r in ordered)
        files['data/'+name+'.csv']=out.getvalue().encode('utf-8')
    es=tables['events'];core=[e for e in es if is_core_event(e)]
    count=lambda vals:dict(sorted(Counter(vals).items()))
    stats=dict(version='0.2.0',cutoff_date='2026-09-22',tables={k:len(v) for k,v in tables.items()},core_events=len(core),core_malicious=sum(e['case_nature']=='malicious_attack' for e in core),core_whitehat=sum(e['case_nature']=='whitehat' for e in core),core_event_ids=[e['event_id'] for e in core],report_supported_records=sum(e['review_status']=='report_supported' for e in es),unresolved_groups=sum(e['record_type']=='unresolved_group' for e in es),by_scope=count(e['scope'] for e in es),by_review_status=count(e['review_status'] for e in es),core_by_year=count(e['event_date'][:4] if e['event_date'] else 'date_unresolved' for e in core),core_by_semantic_category=count(c for e in core for c in e['semantic_categories']),source_access=count(s['access_status'] for s in tables['sources']),known_evidence_roots=len(source_roots(tables['sources'])),unknown_source_independence=sum(s['independence_status']=='unknown' for s in tables['sources']),new_semantically_verified_messages=0,notes=['多标签类别计数之和可大于核心事件数。','known_evidence_roots是已标明的原始分析根源数，不等于每个事件都有多方交叉验证。','未解析组不是独立事件；未核实候选不是正常样本。'])
    src={s['source_id']:s for s in tables['sources']}
    stats['by_case_nature']=count(e['case_nature'] for e in es)
    stats['core_by_protocol']=count(e['protocol'] for e in core)
    stats['core_by_lifecycle_stage']=count(s for e in core for s in e['lifecycle_stages'])
    stats['unique_report_transaction_links']=len({(t['chain'],t['tx_hash'].lower()) for t in tables['transaction_links']})
    stats['event_evidence_coverage']=[dict(event_id=e['event_id'],registered_sources=len(e['source_ids']),directly_read_sources=sum(src[s]['access_status'] in {'full_text_read','partial_text_read'} for s in e['source_ids']),known_evidence_roots=len(source_roots([src[s] for s in e['source_ids']]))) for e in es]
    stats['preserved_message_layer']=json.loads((ROOT.parent/'message-acceptance/manifest.json').read_text(encoding='utf-8'))
    read_rows=lambda p:[json.loads(l) for l in (ROOT.parent/'message-acceptance'/p).read_text(encoding='utf-8').splitlines() if l.strip()]
    messages=read_rows('3-Message/messages.jsonl')
    actual={'observed_transactions':sum(t['evidence_level']=='onchain_observed' for t in read_rows('2-Transaction/observations.jsonl')),'message_candidates':len(messages),'accepted_observations':sum(m['acceptance_outcome']=='accepted' for m in messages),'semantically_verified_messages':sum(m['evidence_level']=='semantically_verified' for m in messages),'strict_benchmark_records':len(read_rows('benchmark/strict.jsonl'))}
    for key,value in actual.items():
        if stats['preserved_message_layer'][key]!=value:raise ValueError('Message manifest mismatch: '+key)
    stats['preserved_message_layer'].update(actual)
    stats['denominators']={'by_scope':'all catalog records including unresolved groups','by_case_nature':'all catalog records, including inherited screening labels','core_by_protocol':'core event count','core_by_lifecycle_stage':'multi-label core events; totals overlap','event_evidence_coverage':'one row per catalog record; registered is not independent'}
    issues=[]
    for e in es:
        flags=[]
        if e['scope']=='unresolved':flags.append('scope_unresolved')
        if e['review_status']!='report_supported':flags.append('not_report_supported')
        if e['conflicts']:flags.append('field_conflict')
        if is_core_event(e) and len(source_roots([src[s] for s in e['source_ids']]))<2:flags.append('fewer_than_two_established_evidence_roots')
        if not any(t['event_id']==e['event_id'] for t in tables['transaction_links']):flags.append('no_new_report_transaction_link')
        if flags:issues.append(dict(event_id=e['event_id'],flags=flags,limitations=e['limitations']))
    files['statistics.json']=json_bytes(stats)
    files['quality_issues.json']=json_bytes(issues)
    return files

def readme_block(stats,english=False):
    t=stats['tables'];m=stats['preserved_message_layer']
    if english:
        lines=[f"Core acceptance events: **{stats['core_events']}** (malicious: {stats['core_malicious']}; whitehat: {stats['core_whitehat']}).",f"Catalog: {t['events']} records; {stats['report_supported_records']} report-supported records; {stats['unresolved_groups']} unresolved groups.",f"Evidence: {t['sources']} registered sources; {t['claims']} claims; {stats['unique_report_transaction_links']} unique report transaction links; {t['search_log']} logged searches.",f"Access status: {json.dumps(stats['source_access'],sort_keys=True)}.",f"Preserved v{m['version']} layer: {m['observed_transactions']} observed transactions, {m['message_candidates']} message candidates, {m['accepted_observations']} acceptance observations, {m['semantically_verified_messages']} semantically verified messages, {m['strict_benchmark_records']} strict benchmark records."]
    else:
        lines=[f"核心异常接受事件：**{stats['core_events']}**（恶意事件 {stats['core_malicious']}；白帽事件 {stats['core_whitehat']}）。",f"目录 {t['events']} 条记录；其中 {stats['report_supported_records']} 条有报告支持，{stats['unresolved_groups']} 条为未解析组。",f"证据包含 {t['sources']} 个来源、{t['claims']} 条主张、{stats['unique_report_transaction_links']} 个唯一报告交易入口、{t['search_log']} 条检索记录。",f"来源访问状态：{json.dumps(stats['source_access'],sort_keys=True)}。",f"保留的 v{m['version']} 消息层：{m['observed_transactions']} 笔交易观察、{m['message_candidates']} 个消息候选、{m['accepted_observations']} 个接受观察、{m['semantically_verified_messages']} 个语义验证消息、{m['strict_benchmark_records']} 个严格基准样本。"]
    return '<!-- MAAD:STATS:BEGIN -->\n'+ '\n\n'.join(lines)+'\n<!-- MAAD:STATS:END -->'

def replace_readme_block(text,block):
    start=text.index('<!-- MAAD:STATS:BEGIN -->');end=text.index('<!-- MAAD:STATS:END -->')+len('<!-- MAAD:STATS:END -->')
    return text[:start]+block+text[end:]

def main():
    files=outputs(load_tables(ROOT/'curation'))
    for rel,data in files.items():
        p=ROOT/rel;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data)
    stats=json.loads(files['statistics.json'])
    for name,en in [('README.md',False),('README.en.md',True)]:
        p=ROOT.parent/name;p.write_text(replace_readme_block(p.read_text(encoding='utf-8'),readme_block(stats,en)),encoding='utf-8')
    print((ROOT/'statistics.json').read_text(encoding='utf-8'))
if __name__=='__main__':main()
