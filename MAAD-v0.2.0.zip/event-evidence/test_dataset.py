import copy
import tempfile
import unittest
from pathlib import Path
from model import is_core_event, require_acceptance_evidence, validate_tables, source_roots
from build import encode_cell, decode_cell

def event():
    return dict(event_id='TEST-E1',record_type='event',scope='in_scope',case_nature='malicious_attack',review_status='report_supported',conflicts=[])

class EvidenceGateTests(unittest.TestCase):
    def test_group_disclosure_and_unreviewed_are_not_core(self):
        self.assertTrue(is_core_event(event()))
        for delta in ({'record_type':'unresolved_group'},{'case_nature':'vulnerability_disclosure'},{'review_status':'inherited_candidate'},{'scope':'unresolved'},{'conflicts':[{'blocks_core':True}]}):
            self.assertFalse(is_core_event(dict(event(),**delta)))
        self.assertTrue(is_core_event(dict(event(),case_nature='whitehat')))

    def test_snippet_cannot_prove_acceptance(self):
        claim=dict(event_id='TEST-E1',source_id='S1',claim_type='acceptance_mechanism',stance='supports',locator='Root cause')
        source=dict(source_id='S1',access_status='search_snippet_only')
        with self.assertRaises(ValueError): require_acceptance_evidence(event(),[claim],{'S1':source})
        source['access_status']='partial_text_read'
        require_acceptance_evidence(event(),[claim],{'S1':source})
        claim['stance']='context'
        with self.assertRaises(ValueError): require_acceptance_evidence(event(),[claim],{'S1':source})

    def test_copied_and_unknown_sources_do_not_inflate_roots(self):
        sources=[dict(evidence_origin_id='R1',independence_status='established'),dict(evidence_origin_id='R1',independence_status='derived'),dict(evidence_origin_id=None,independence_status='unknown')]
        self.assertEqual(source_roots(sources),{'R1'})

    def test_csv_roundtrip_null_list_unicode(self):
        for value in (None,[],['Ethereum','中文'],[{'blocks_core':False}], '0', '2026-09-22'):
            self.assertEqual(decode_cell(encode_cell(value),value),value)

    def test_real_data_and_mutations(self):
        from build import load_tables, ROOT
        tables=load_tables(ROOT/'curation')
        validate_tables(tables,ROOT.parent)
        bad=copy.deepcopy(tables)
        bad['sources'].append(bad['sources'][0])
        with self.assertRaises(ValueError): validate_tables(bad,ROOT.parent)
        bad=copy.deepcopy(tables)
        bad['claims'][0]['source_id']='missing'
        with self.assertRaises(ValueError): validate_tables(bad,ROOT.parent)
        bad=copy.deepcopy(tables)
        bad['upstream_map'].pop()
        with self.assertRaises(ValueError): validate_tables(bad,ROOT.parent)
        for table,field,value in [('case_map','source_ids',['SRC-MISSING']),('case_map','disposition','unreviewed'),('upstream_map','disposition','unreviewed'),('case_map','reason',''),('sources','evidence_origin_id','SRC-MISSING')]:
            bad=copy.deepcopy(tables);bad[table][0][field]=value
            with self.assertRaises(ValueError,msg=table+'.'+field): validate_tables(bad,ROOT.parent)

    def test_build_statistics_match_actual_message_evidence(self):
        import json
        from build import outputs,load_tables,ROOT,readme_block,replace_readme_block
        result=outputs(load_tables(ROOT/'curation'))
        stats=json.loads(result['statistics.json'])
        observations=[json.loads(l) for l in (ROOT.parent/'message-acceptance/2-Transaction/observations.jsonl').read_text(encoding='utf-8').splitlines()]
        self.assertEqual(stats['preserved_message_layer']['observed_transactions'],sum(bool(t['evidence_ids']) for t in observations))
        for english in (False,True):
            block=readme_block(stats,english)
            self.assertEqual(replace_readme_block(block,block),block)
        self.assertEqual(len(stats['event_evidence_coverage']),len(load_tables(ROOT/'curation')['events']))

if __name__=='__main__': unittest.main()
