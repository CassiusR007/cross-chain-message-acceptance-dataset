# v0.2.0 字段字典

七张表均以UTF-8 JSONL为人工输入，CSV/JSONL为生成输出。JSON null对应CSV空字段；list/dict字段在CSV内编码为JSON。所有ID稳定，不随排序和日期修订重排。

## events

- `event_id`：MAAD-E六位ID；`name`、`protocol`：名称/协议。未核实记录仍可含继承标题中的待验证表述。
- `date_raw`：报告或上游日期文字；`event_date`：ISO日期或null；`date_precision`：day/range/unknown；`date_basis`：继承、报告日期、时区换算或冲突处理依据。普通报告日期不默认UTC。
- `chains`：关联链上下文数组，不保证都是已验证受害链；`direction`：已知时的业务方向，否则null；`deployment`：具体版本/地址证据，当前多为null。
- `record_type`：event或unresolved_group。组不得计入核心事件数。
- `scope`：in_scope / boundary / out_of_scope / unresolved。边界及范围外不是正常负样本。
- `case_nature`：malicious_attack / whitehat / failed_attempt / vulnerability_disclosure / operational_failure / unknown。事件级描述不向所有参与者传播。
- `root_cause`：报告支持的根因转述或null；`semantic_categories`和`lifecycle_stages`：本数据集的研究标注，不冒充报告原有分类。
- `source_ids`：sources外键数组；`review_status`：report_supported / inherited_candidate / unresolved。
- `scope_reason`：本轮范围判定与证据等级；`campaign_id`：共享攻击机制/轮次组，可用于防泄漏分组。
- `conflicts`：字段冲突对象数组，含`blocks_core`；若true禁止核心纳入。`limitations`：证据缺口；`reviewed_at`：审阅日期。

## 语义与生命周期枚举

- SOURCE_SEMANTICS：真实调用/消息不代表业务事实成立。
- EMITTER_AUTH：发出者、远端对等体或源通道未可靠认证。
- ASSET_BINDING：资产标识或映射歧义。
- VALUE_CONSERVATION：声明、入库和出库价值不一致。
- PROOF_VALIDITY：证明/验证上下文不满足有效性要求。
- PROOF_BINDING：证明或签名未绑定实际执行的字段/叶子/行。
- SIGNER_TRUST：签名权限被控制或滥用；不表示签名数学上无效。
- OBSERVATION_TRUST：链下观测输入遭欺骗。
- TRUST_CONFIG：可信角色、门槛、根或配置异常。
- DOMAIN_BINDING：链/域隔离失效；REPLAY：一次性授权被重复消费。
- EXEC_AUTH：已认证消息获得不应拥有的业务执行权限。
- FINALITY：接受的状态未满足预期最终性信任要求。

阶段依次为source_observation、attestation、verification、acceptance、execution。标注可多选，不表示已取得每个阶段的完整链上记录。

## sources

`source_id`、`title`、`publisher`、`url`为来源身份；`published_at`为已知发布日期或null；`accessed_at`为访问日。`source_type`区分project_postmortem/security_analysis。`access_status`为full_text_read、partial_text_read、search_snippet_only、unavailable。`locator`是章节定位，不依赖浏览工具临时行号。`summary_zh`为简短转述，`access_notes`记访问局限。`evidence_origin_id`为已知分析根源，`independence_status`为established/derived/unknown；未知不计独立根源。

## claims

`claim_id`、`event_id`、`source_id`构成逐主张来源关系；`claim_type`为occurrence/acceptance_mechanism/root_cause/date/transaction/loss/recovery；`statement_zh`是具体陈述；`stance`为supports/contradicts/context；`locator`定位报告正文；`observation_method=report_statement`明确不是链上重放；`conflict_id`可关联冲突，没有则null。

## upstream_map / case_map

`upstream_event_id`对应冻结的events.csv，`upstream_commit`固定上游版本，`record_type`保留上游类型，`event_ids`列出映射，`disposition`为matched/split/unresolved_group/excluded，`review_basis`保存本轮原因与继承描述，`reviewed_at`记录审阅日。映射中的matched不等于报告核实。

`legacy_case_id`对应research_sources.json的27条线索；`event_ids`和`source_ids`为映射；`disposition`使用该事件的review_status，`reason`说明处理结果，`reviewed_at`记录审阅日。

## transaction_links

`link_id`为关系ID；`event_id`、`source_ids`为外键；`chain`与`tx_hash`指定真实报告入口；`upstream_transaction_id`未完成精确关联时为null；`role`为preparation/submission/acceptance/execution/transfer/unknown；`verification_status=report_link_only`；`notes`说明角色与核验局限。一笔交易可能含多条消息，本表不是消息配对表。

## search_log

`search_id`、`searched_at`、`query`、`method`记录实际检索；`result_urls`为保存下来的批次结果，早期未保留则为空；`outcome`和`limitations`说明访问/归并与日志缺口。命中URL不自动进入证据表。

## 生成文件

statistics.json记录表大小、核心ID、范围/年份/多标签分布、来源状态和根源数。quality_issues.json列出未核实、字段冲突、独立根源不足与缺少新交易入口。release/inputs.json校验冻结旧层，release/manifest.json校验发布文件；清单及发布后verification.json不自引用哈希。
