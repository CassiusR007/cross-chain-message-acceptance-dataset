import tempfile
import unittest
from pathlib import Path
from package import contained_path,allowed,inventory

class PackageTests(unittest.TestCase):
    def test_escape_and_unknown_paths_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            for p in ('../outside',str(root.parent/'outside')):
                with self.assertRaises(ValueError):contained_path(root,p)
            self.assertFalse(allowed('secrets.txt'))
            self.assertFalse(allowed('.git/config'))
            self.assertFalse(allowed('event-evidence/__pycache__/model.pyc'))
            self.assertFalse(allowed('docs/private.pdf'))
            self.assertTrue(allowed('event-evidence/curation/events.jsonl'))

    def test_inventory_hashes_exact_bytes(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'README.md').write_bytes(b'hello\n')
            (root/'private.txt').write_text('not released')
            rows=inventory(root)
            self.assertEqual([r['path'] for r in rows],['README.md'])
            self.assertEqual(rows[0]['bytes'],6)
            self.assertEqual(rows[0]['sha256'],'5891b5b522d5df086d0ff0b110fbd9d21bb4fc7163af34d08286a2e846f6be03')

if __name__=='__main__':unittest.main()
