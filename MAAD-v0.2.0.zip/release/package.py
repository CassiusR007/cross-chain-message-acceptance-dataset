"""Publish an explicit allowlist, never the entire working directory."""
import hashlib
import json
import zipfile
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1]
ROOT_FILES={'.gitignore','README.md','README.en.md','README.upstream.md','DATA_CARD.md','LICENSE','NOTICE.md','CITATION.cff','CHANGELOG.md'}
DIRS={'1-Event','2-Transaction','message-acceptance','event-evidence','docs','release'}
SUFFIXES={'.csv','.json','.jsonl','.md','.py','.cff'}

def contained_path(root,relative):
    rel=Path(relative)
    if rel.is_absolute() or '..' in rel.parts:raise ValueError('Invalid relative path')
    candidate=(root/rel).resolve()
    candidate.relative_to(root.resolve())
    return candidate

def allowed(relative):
    p=PurePosixPath(relative)
    if p.is_absolute() or '..' in p.parts:return False
    if any(x.startswith('.') or x=='__pycache__' for x in p.parts):return relative=='.gitignore'
    if len(p.parts)==1:return relative in ROOT_FILES
    if p.parts[0] not in DIRS or p.suffix not in SUFFIXES:return False
    if p.parts[0]=='docs':return len(p.parts)>2 and p.parts[1]=='superpowers' and p.suffix=='.md'
    if p.parts[0]=='release':return p.name in {'package.py','test_package.py','inputs.json','verification.json','manifest.json'}
    return True

def inventory(root=ROOT):
    rows=[]
    for p in sorted(root.rglob('*')):
        rel=p.relative_to(root).as_posix()
        if not p.is_file() or not allowed(rel) or rel in {'release/manifest.json','release/verification.json'}:continue
        checked=contained_path(root,rel)
        if p.is_symlink():raise ValueError('Do not package symlinks: '+rel)
        raw=checked.read_bytes()
        rows.append(dict(path=rel,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    return rows

def main():
    rows=inventory()
    manifest=dict(version='0.2.0',files=rows,exclusions=['release/manifest.json (self-reference)','release/verification.json (post-publication record)'])
    (ROOT/'release/manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    dest=ROOT/'release/MAAD-v0.2.0.zip'
    with zipfile.ZipFile(dest,'w',zipfile.ZIP_DEFLATED) as archive:
        for r in rows:archive.write(contained_path(ROOT,r['path']),r['path'])
        archive.write(ROOT/'release/manifest.json','release/manifest.json')
    print(json.dumps({'files':len(rows),'bytes':sum(r['bytes'] for r in rows),'zip':str(dest)}))
if __name__=='__main__':main()
